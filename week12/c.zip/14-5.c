#include <stdio.h>

int main() {
	FILE*file;
	char str1[]= "C language, ";
	char str2[] = "Text File!!!";

	file = fopen("twostring.txt", "w");
	if (file ==NULL) {
		printf("파일을 열 수 없습니다. \n");
		return 1;
	}

	fprintf(file, "%s", str1);
	fprintf(file, "%s", str2);

	fclose(file);

	printf("twostring.txt 파일에 문자열 '%s%s'를 성공적으로 썼습니다. \n",str1,str2);
	return 0;
}
