#include <stdio.h>

int main() {
	FILE*file;
	char str1[150];

	file = fopen("twostring.txt","r");
	if (file == NULL){
		printf("파일을 열 수 없습니다.\n");
		return 1;
	}

	if (fgets(str1, sizeof(str1),file)==NULL){
		printf("첫 번째 문자열을 읽는 데 실패했습니다.\n");
		fclose(file);
		return 1;
	}

	fclose(file);

	printf("twostring.txt 파일에서 문자열'%s'를 성공적으로 읽었습니다.\n",str1);
	return 0;
}
