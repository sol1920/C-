#include <stdio.h>

struct Student{
	char name[50];
	int score;
};

int main() {
	int count;
	//학생 구조체 변수  선언
	struct Student s;

	FILE *fp;
	FILE *pass;
	FILE *fail;
	//구조체 멤버변수 값을 저장할 파일 포인처 선언
	FILE *fp;
	fp = fopen("student.txt","w");

	if (fp == NULL) {
		printf("파일을 열 수 없습니다. \n");
		return 0;
	}
	//학생 수 입력 받고 count 변수에 저장 후 반복문에서 학생수만큼 입력( 이름, 점수)
	//구조체 멤버 변수에 저장 받아라
	//ex) 학생 수 입력 : 5
	printf("학생 수 입력");
	scanf("%d",&count);

	for (int i=0; i<count i++)
	{
		printf("\n%d번째 학생 이름", i + 1);
		scanf("%49s", s.name);

		printf("점수: ");
		scanf("%d", &s.score);
		//fprintf(파일포인터, 서식문자, 저장할 값)
		fprintf(fp, "%s %d\n"s.name, s.score);
	}
	fclose(fp);

	fp = fopen("student.txt","r");
	pass = fopen("pass.txt","w");
	fail = fopen("fail.txt","w");

	//만약 세 파일 중 하나라도 열기에 실패했다면
	if(fp == NULL || pass == NULL || fail == NULL)
	{
		//오류 메세지를 출력한다
		printf("파일 열기 실패\n");
		//성공적으로 열린 파일은 닫는다
		if(fp != NULL) fclose(fp);
		if(pass != NULL) fclose(pass);
		if(fail != NULL) fclose(fail);
		
		//프로그램을 종료한다
		return 1;
	}
	
	//파일에서 이름과 점수를 모두 읽을 수 있는 동안 반복한다
	while (fscanf(fp, "%49s %d", s.name, &s.score) ==2) {
		if(s.score >= 80){
			fprintf(pass, "%s %d\n", s.name, s.score);
		}
		else{
			fprintf(fail, "%s %d\n", s.name, s.score);
		}
	}
	fclose(fp);
	fclose(pass);
	fclose(fail);

	printf("파일 저장 및 분류 완료~");


}
